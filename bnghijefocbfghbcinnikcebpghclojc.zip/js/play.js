/**
 * Attention to moderators:
 *
 * This is not spam redirection to the some website with a game!
 * This website is not a game. Game functionality will be added by content scripts in this extension.
 * See content_scripts section in the manifest.json
 *
 * Reasons to embed game into this website this way are
 * Unity engine and unblocking this game for students.
 */
location.href = 'https://sites.google.com/site/34fgdg6uyhg/';